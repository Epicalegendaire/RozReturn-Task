import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, davies_bouldin_score
import umap
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import norm
import os
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Set paths and parameters
DATA_PATH = './data/'
DEPTH_FOLDER = 'depth20_1000ms'
AGGTRADE_FOLDER = 'aggTrade'
DATES = ['20250314', '20250315', '20250316', '20250317']
WINDOW_SIZES = [10, 30]  # seconds for rolling calculations
N_CLUSTERS_RANGE = range(2, 8)

def load_data():
    """Load and preprocess depth and trade data."""
    depth_dfs = []
    trade_dfs = []
    
    for date in DATES:
        depth_file = os.path.join(DATA_PATH, DEPTH_FOLDER, f'BNBFDUSD_{date}.txt')
        depth_df = pd.read_csv(depth_file)
        depth_df['Time'] = pd.to_datetime(depth_df['Time'].str.split(' \+').str[0])
        depth_df = depth_df.groupby('Time').mean().reset_index()
        depth_dfs.append(depth_df)
        
        trade_file = os.path.join(DATA_PATH, AGGTRADE_FOLDER, f'BNBFDUSD_{date}.txt')
        trade_df = pd.read_csv(trade_file)
        trade_df['Time'] = pd.to_datetime(trade_df['Time'].str.split(' \+').str[0])
        trade_dfs.append(trade_df)
    
    depth_data = pd.concat(depth_dfs)
    trade_data = pd.concat(trade_dfs)
    
    depth_data = depth_data.set_index('Time')
    trade_data = trade_data.set_index('Time')
    
    return depth_data, trade_data

def engineer_features(depth_data, trade_data):
    """Extract features from order book and trade data."""
    features = pd.DataFrame(index=depth_data.index)
    
    features['spread'] = depth_data['AskPriceL1'] - depth_data['BidPriceL1']
    features['imbalance_lvl1'] = (depth_data['BidQtyL1'] - depth_data['AskQtyL1']) / (depth_data['BidQtyL1'] + depth_data['AskQtyL1'])
    features['microprice'] = (depth_data['BidPriceL1'] * depth_data['AskQtyL1'] + 
                            depth_data['AskPriceL1'] * depth_data['BidQtyL1']) / (depth_data['BidQtyL1'] + depth_data['AskQtyL1'])
    
    bid_qty_cols = [f'BidQtyL{i}' for i in range(1, 21)]
    ask_qty_cols = [f'AskQtyL{i}' for i in range(1, 21)]
    features['cum_bid_qty'] = depth_data[bid_qty_cols].sum(axis=1)
    features['cum_ask_qty'] = depth_data[ask_qty_cols].sum(axis=1)
    
    features['mid_price'] = (depth_data['BidPriceL1'] + depth_data['AskPriceL1']) / 2
    features['returns'] = np.log(features['mid_price'] / features['mid_price'].shift(1))
    
    for window in WINDOW_SIZES:
        features[f'volatility_{window}s'] = features['returns'].rolling(window).std()
    
    trade_data['buy_volume'] = trade_data['Quantity'] * (trade_data['IsMarketMaker'] == False)
    trade_data['sell_volume'] = trade_data['Quantity'] * (trade_data['IsMarketMaker'] == True)
    
    buy_volume = trade_data['buy_volume'].resample('1S').sum().reindex(features.index, method='ffill')
    sell_volume = trade_data['sell_volume'].resample('1S').sum().reindex(features.index, method='ffill')
    
    features['volume_imbalance'] = (buy_volume - sell_volume) / (buy_volume + sell_volume + 1e-10)
    
    for window in WINDOW_SIZES:
        features[f'cum_volume_{window}s'] = (buy_volume.rolling(window).sum() + sell_volume.rolling(window).sum())
    
    trade_data['vwap'] = (trade_data['Price'] * trade_data['Quantity']).cumsum() / trade_data['Quantity'].cumsum()
    vwap = trade_data['vwap'].resample('1S').last().reindex(features.index, method='ffill')
    features['vwap_shift'] = vwap.diff()
    
    bid_slopes = []
    ask_slopes = []
    for i in range(1, 20):
        bid_slope = (depth_data[f'BidQtyL{i}'] - depth_data[f'BidQtyL{i+1}']) / (depth_data[f'BidPriceL{i}'] - depth_data[f'BidPriceL{i+1}'])
        ask_slope = (depth_data[f'AskQtyL{i}'] - depth_data[f'AskQtyL{i+1}']) / (depth_data[f'AskPriceL{i}'] - depth_data[f'AskPriceL{i+1}'])
        bid_slopes.append(bid_slope)
        ask_slopes.append(ask_slope)
    
    features['avg_bid_slope'] = pd.concat(bid_slopes, axis=1).mean(axis=1)
    features['avg_ask_slope'] = pd.concat(ask_slopes, axis=1).mean(axis=1)
    
    return features.dropna()

def normalize_and_reduce(features):
    """Normalize features and apply PCA."""
    scaler = StandardScaler()
    normalized_features = scaler.fit_transform(features)
    
    pca = PCA(n_components=0.95)
    reduced_features = pca.fit_transform(normalized_features)
    
    print(f"PCA: {reduced_features.shape[1]} components explain 95% of variance")
    
    return reduced_features, scaler, pca

def cluster_data(features):
    """Apply K-means clustering and select optimal number of clusters."""
    silhouette_scores = []
    db_scores = []
    models = {}
    
    for k in N_CLUSTERS_RANGE:
        kmeans = KMeans(n_clusters=k, random_state=42)
        labels = kmeans.fit_predict(features)
        
        silhouette = silhouette_score(features, labels)
        db = davies_bouldin_score(features, labels)
        
        silhouette_scores.append(silhouette)
        db_scores.append(db)
        models[k] = kmeans
    
    optimal_k = N_CLUSTERS_RANGE[np.argmax(silhouette_scores)]
    print(f"Optimal number of clusters: {optimal_k}")
    
    plt.figure(figsize=(12, 8))
    plt.plot(N_CLUSTERS_RANGE, silhouette_scores, marker='o', label='Silhouette Score')
    plt.plot(N_CLUSTERS_RANGE, db_scores, marker='x', label='Davies-Bouldin Score')
    plt.xlabel('Number of Clusters')
    plt.ylabel('Score')
    plt.title('Clustering Metrics')
    plt.legend()
    plt.tight_layout()
    plt.savefig('clustering_metrics.png', bbox_inches='tight')
    plt.close()
    
    return models[optimal_k].labels_, optimal_k

def analyze_regimes(features, labels, optimal_k):
    """Analyze and label market regimes."""
    regime_stats = []
    for cluster in range(optimal_k):
        mask = labels == cluster
        cluster_features = features[mask]
        
        stats = {
            'Cluster': cluster,
            'Volatility': cluster_features['volatility_30s'].mean(),
            'Spread': cluster_features['spread'].mean(),
            'Liquidity': cluster_features['cum_bid_qty'].mean() + cluster_features['cum_ask_qty'].mean(),
            'Trend_Strength': np.abs(cluster_features['returns'].mean() / cluster_features['returns'].std()),
            'Count': mask.sum()
        }
        
        volatility_label = 'Volatile' if stats['Volatility'] > features['volatility_30s'].quantile(0.75) else 'Stable'
        liquidity_label = 'Liquid' if stats['Liquidity'] > features['cum_bid_qty'].quantile(0.75) + features['cum_ask_qty'].quantile(0.75) else 'Illiquid'
        trend_label = 'Trending' if stats['Trend_Strength'] > features['returns'].mean() / features['returns'].std() else 'Mean-Reverting'
        
        stats['Regime'] = f"{trend_label} & {liquidity_label} & {volatility_label}"
        regime_stats.append(stats)
    
    return pd.DataFrame(regime_stats)

def visualize_results(features, labels, optimal_k, regime_stats):
    """Visualize clustering results with improved plots."""
    reducer = umap.UMAP(random_state=42)
    embedding = reducer.fit_transform(features.drop(columns=['mid_price', 'returns']))
    
    regime_names = [regime_stats.loc[regime_stats['Cluster'] == label, 'Regime'].values[0] for label in labels]
    
    plt.figure(figsize=(12, 8))
    sns.scatterplot(x=embedding[:, 0], y=embedding[:, 1], hue=regime_names, palette='deep')
    plt.xlabel('UMAP1')
    plt.ylabel('UMAP2')
    plt.title('UMAP Visualization of Market Regimes')
    plt.tight_layout()
    plt.savefig('umap_clusters.png', bbox_inches='tight')
    plt.close()
    
    fig, ax1 = plt.subplots(figsize=(18, 8))
    ax1.step(features.index, labels, where='post', label='Regime', color='blue')
    ax1.set_xlabel('Time')
    ax1.set_ylabel('Regime')
    ax1.set_title('Regime Evolution Over Time')
    
    ax1.set_yticks(range(optimal_k))
    ax1.set_yticklabels([regime_stats.loc[regime_stats['Cluster'] == i, 'Regime'].values[0] for i in range(optimal_k)])
    
    ax2 = ax1.twinx()
    ax2.plot(features.index, features['mid_price'], label='Mid Price', color='orange')
    ax2.set_ylabel('Mid Price')
    
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper left')
    
    plt.tight_layout()
    plt.savefig('regime_evolution.png', bbox_inches='tight')
    plt.close()

def compute_regime_transitions(labels, regime_stats):
    """Calculate and visualize regime transition probabilities."""
    transitions = pd.crosstab(pd.Series(labels[:-1], name='From'), pd.Series(labels[1:], name='To'), normalize='index')
    
    regime_map = regime_stats.set_index('Cluster')['Regime'].to_dict()
    transitions.index = transitions.index.map(regime_map)
    transitions.columns = transitions.columns.map(regime_map)
    
    plt.figure(figsize=(14, 10))
    sns.heatmap(transitions, annot=True, cmap='Blues')
    plt.title('Regime Transition Probabilities')
    plt.xticks(rotation=45, ha='right', fontsize=10)
    plt.yticks(rotation=0, fontsize=10)
    plt.tight_layout()
    plt.savefig('regime_transitions.png', bbox_inches='tight')
    plt.close()
    
    return transitions

def main():
    depth_data, trade_data = load_data()
    features = engineer_features(depth_data, trade_data)
    reduced_features, scaler, pca = normalize_and_reduce(features)
    labels, optimal_k = cluster_data(reduced_features)
    regime_stats = analyze_regimes(features, labels, optimal_k)
    print("Regime Statistics:")
    print(regime_stats)
    regime_stats.to_csv('regime_stats.csv', index=False)
    visualize_results(features, labels, optimal_k, regime_stats)
    transitions = compute_regime_transitions(labels, regime_stats)
    print("\nRegime Transition Probabilities:")
    print(transitions)

if __name__ == '__main__':
    main()